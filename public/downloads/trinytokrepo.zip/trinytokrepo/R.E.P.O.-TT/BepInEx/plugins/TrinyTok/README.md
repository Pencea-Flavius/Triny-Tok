# TrinyTok

Bridge TikTok live gifts to R.E.P.O. effects in real-time.

## Requirements

- [BepInExPack](https://thunderstore.io/c/repo/p/BepInEx/BepInExPack/)
- [REPOLib](https://thunderstore.io/c/repo/p/Zehs/REPOLib/)
- TrinyTok Server running on your PC

## Setup

1. Install the mod via r2modman.
2. Start the TrinyTok server app.
3. Launch R.E.P.O. — the mod connects automatically to `127.0.0.1:51337`.
4. Press **F8** to toggle the connection manually if needed.

## Configuration

Edit `BepInEx/config/com.trinytok.repo.cfg` to change:
- `Host` — server IP (default: `127.0.0.1`)
- `Port` — server port (default: `51337`)
- `ToggleConnectKey` — hotkey to connect/disconnect (default: `F8`)

## Effects

Supports player effects (invincible, infinite stamina, speed, disable input, anti-gravity),
teleports, health/damage, upgrades, enemy spawns, item spawns, and world effects.
